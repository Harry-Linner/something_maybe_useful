#define __INTRINSIC_ONLYSPECIAL
#define __INTRINSIC_SPECIAL__InterlockedCompareExchange64 /* Causes code generation in intrin-impl.h */

#include <intrin.h>
