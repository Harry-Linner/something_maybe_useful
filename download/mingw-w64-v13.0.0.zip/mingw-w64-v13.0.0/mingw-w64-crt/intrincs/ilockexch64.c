#define __INTRINSIC_ONLYSPECIAL
#define __INTRINSIC_SPECIAL__InterlockedExchange64 /* Causes code generation in intrin-impl.h */

#include <intrin.h>
