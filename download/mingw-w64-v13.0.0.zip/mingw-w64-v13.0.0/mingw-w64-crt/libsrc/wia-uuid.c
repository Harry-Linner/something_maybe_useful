/* unknwn-uuid.c */
/* Generate GUIDs for WIA interfaces */

#define INITGUID
#include <basetyps.h>
#include <wia.h>
